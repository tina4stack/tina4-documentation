# Copyright (c) 2026 Code Infinity
# SPDX-License-Identifier: MPL-2.0
"""The local AI model server - served by Tina4 itself.

No FastAPI, no Flask: Tina4 handles the HTTP, and the tokens come from the vendored
``ai_engine`` code (MLX on Apple Silicon, torch on CUDA or CPU) in ``lib/`` - the
server clones nothing. These routes mirror the harness model server exactly - same
``/generate``, ``/describe``, ``/health``, ``/memory`` paths and the same request
and reply shapes - so anything already pointed at the harness server keeps working
when it is pointed here instead.

The handlers are plain ``def`` on purpose. A generation blocks until the model
replies, so Tina4 runs it on a worker thread and the event loop stays free for the
next request. One model cannot run two generations at once, so a lock lets them
queue rather than collide.
"""
import threading

from tina4_python.core.router import get, post, noauth

from ai_engine.model import Settings, load_model

_model = None
_load_lock = threading.Lock()   # load the weights once, however many requests race in
_gen_lock = threading.Lock()    # one generation at a time on the single model


def _model_instance():
    """The one shared model, loaded locally on first use (never via a remote proxy)."""
    global _model
    if _model is None:
        with _load_lock:
            if _model is None:
                _model = load_model(allow_remote=False, settings=Settings())
    return _model


@get("/health")
def health(request, response):
    return response("ok")


@get("/info")
def info(request, response):
    model = _model_instance()
    return response({"repo_id": model.repo_id, "backend": model.backend, "device": model.device})


@get("/memory")
def memory(request, response):
    return response(_model_instance().memory())


@noauth()
@post("/generate")
def generate(request, response):
    body = request.body or {}
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        return response({"error": "messages must be a non-empty list"}, 400)
    model = _model_instance()
    with _gen_lock:
        text = model.generate(
            messages,
            max_tokens=body.get("max_tokens"),
            temperature=body.get("temperature"),
            enable_thinking=bool(body.get("enable_thinking", True)),
        )
    return response({"text": text})


@noauth()
@post("/describe")
def describe(request, response):
    body = request.body or {}
    image = body.get("image")
    if not isinstance(image, str) or not image:
        return response({"error": "image (a local file path) is required"}, 400)
    model = _model_instance()
    with _gen_lock:
        text = model.describe(
            image,
            body.get("prompt", "Describe this image."),
            max_tokens=int(body.get("max_tokens", 512)),
        )
    return response({"text": text})
